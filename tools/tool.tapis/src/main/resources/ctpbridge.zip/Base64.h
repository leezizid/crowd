#ifndef _BASE64_H__
#define _BASE64_H__

#include <bitset>
#include <iostream>

std::string Base64_Encode(std::string toEncode);

std::string Base64_Decode(std::string toDecode);

#endif
